/**
 * Return the name of a component
